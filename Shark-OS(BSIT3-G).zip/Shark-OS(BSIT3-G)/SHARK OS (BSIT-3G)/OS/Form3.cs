﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace OS
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            panel2.Hide();
            panel4.Hide();
            panel5.Hide();
        }
        private void Form3_Load(object sender, EventArgs e)
        {
            label5.Text = DateTime.Now.ToLongTimeString();
        }

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            panel2.Show();
        }

        private void Form3_Click(object sender, EventArgs e)
        {
            panel2.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            panel4.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel4.Hide();
        }

        private void bunifuImageButton2_Click(object sender, EventArgs e)
        {
            Process chrome = Process.Start("chrome.exe");
        }

        private void bunifuImageButton11_Click(object sender, EventArgs e)
        {
            Process chrome = Process.Start("chrome.exe");
        }

        private void bunifuImageButton12_Click(object sender, EventArgs e)
        {
            Process control = Process.Start("control.exe");
        }

        private void bunifuImageButton13_Click(object sender, EventArgs e)
        {
            Process exp = Process.Start("explorer.exe");
        }

        private void bunifuImageButton3_Click(object sender, EventArgs e)
        {
            Process word = Process.Start("winword.exe");
        }

        private void bunifuImageButton4_Click(object sender, EventArgs e)
        {
            Process powerpnt = Process.Start("powerpnt.exe");
        }

        private void bunifuImageButton5_Click(object sender, EventArgs e)
        {
            Process excel = Process.Start("excel.exe");
        }

        private void bunifuImageButton6_Click(object sender, EventArgs e)
        {
            Process paint = Process.Start("mspaint.exe");
        }

        private void bunifuImageButton7_Click(object sender, EventArgs e)
        {
            Process ai = Process.Start("Illustrator.exe");
        }

        private void bunifuImageButton8_Click(object sender, EventArgs e)
        {
            Process cmd = Process.Start("cmd.exe");
        }

        private void bunifuImageButton9_Click(object sender, EventArgs e)
        {
            Process ps = Process.Start("Photoshop.exe");
        }

        private void bunifuImageButton10_Click(object sender, EventArgs e)
        {
            Process skp = Process.Start("SketchUp.exe");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel5.Hide();
        }

        private void bunifuImageButton14_Click(object sender, EventArgs e)
        {
            panel5.Show();
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
